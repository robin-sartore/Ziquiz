
    function refresh(){
    console.log(sessionStorage.getItem("1"));
    nick = sessionStorage.getItem("1");
    document.getElementById("nicknamefinal").innerHTML= nick;

}

