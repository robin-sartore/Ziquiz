function refreshpt() {
    let ptfinale = sessionStorage.getItem("4"); // Recupera il punteggio
    let difficolta = sessionStorage.getItem("3"); // Recupera la difficoltà

    if (!ptfinale || !difficolta) {
        console.error("Errore: punteggio o difficoltà mancanti.");
        return;
    }

    document.getElementById('risultato').innerHTML = ptfinale;

    let totdomande;
    if (difficolta === "FACILE") {
        totdomande = `${ptfinale / 10}/10`;
    } else if (difficolta === "MEDIO") {
        totdomande = `${ptfinale / 20}/20`;
    } else {
        totdomande = `${ptfinale / 30}/30`;
    }
    document.getElementById('totdomande').innerHTML = totdomande;
}

function backcat() {
    close();
    var pag = window.open("Ziquiz.html");
}

setTimeout(mostraDatiSalvati, 1000); // Aspetta 1 secondo prima di mostrare i dati

// Funzione per recuperare i dati (GET) e mostrarli
// Funzione per recuperare i dati (GET) e mostrarli
function mostraDatiSalvati() {
    const categoria = sessionStorage.getItem("2");
    const difficolta = sessionStorage.getItem("3");

    // Controllo se categoria o difficoltà non sono definiti
    if (!categoria || !difficolta) {
        console.error("Errore: categoria o difficoltà mancanti.");
        return;
    }

    // Esegui la richiesta GET
    fetch(`../php/record.php?categoria=${categoria}&difficolta=${difficolta}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Errore nella risposta: ${response.status}`);
        }
        return response.json(); // Recupera la risposta come JSON
    })
    .then(jsonData => {
        console.log('Dati salvati:', jsonData);
        
        // Verifica se la risposta contiene un errore
        if (jsonData.status === 'error') {
            console.error(jsonData.message); // Mostra il messaggio di errore
            return; // Non procedere ulteriormente se c'è un errore
        }

        // Se la risposta è valida (array di dati)
        const container = document.getElementById('datiSalvati');
        container.innerHTML = ''; // Svuota il contenitore

        // Mostra i dati
        jsonData.forEach(record => {
            const elemento = document.createElement('div');
            elemento.textContent = `Nome: ${record.nome}, Punteggio: ${record.punteggio}`;
            container.appendChild(elemento);
        });

        // Adatta dinamicamente l'altezza del div risultato
        const risultatoDiv = document.querySelector('.risultato');
        const numeroDati = jsonData.length;  // Numero di record salvati
        const altezzaDati = numeroDati * 30;  // Ogni record aggiunge 30px (puoi cambiare questo valore)
        risultatoDiv.style.height = `${400 + altezzaDati}px`; // Aggiungi una base di 400px, più altezza dinamica

    })
    .catch(error => {
        console.error('Errore nella richiesta:', error);
    });
}